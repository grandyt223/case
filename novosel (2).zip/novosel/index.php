<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <title>Новосёл | Агентство недвижимости I Сысерть</title>
</head>
<body>
<?php
    // Инициализация подключения к базе данных
    $host = '127.0.0.1';
    $db = 'novosel';
    $user = 'root'; // Ваше имя пользователя
    $pass = 'root'; // Ваш пароль
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
    ?>
    <header>
        <div class="navigation">
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="menu">
                <ul class="topmenu">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="sales.php">В продаже</a></li>
                    <li><a href="about.php">О нас</a></li>
                </ul>
            </div>
            <div class="cont">
                <a href="tel:+73433720808">+7 (343) 372-08-08</a>
            </div>
        </div>
    </header>

    <main>
        <section style="background-image: url(img/bg2.jpg);" class="cont2">
            <div class="content">
                <h1 style="padding: 20px;">Купить квартиру</h1>
                <!-- <div class="left-right">
                    <p>Забота об интересах и удобстве клиента – основной фактор,<br>
                     который сделал наше агентство одним из лучших!</p>
                    <p>Делаем своё дело уже 22 года, защищая интересы наших клиентов<br>
                     и гарантируя юридическую чистоту сделок.</p>
                </div> -->
                <div class="ocen">
                <h2>Хотите оценить недвижимость по<br> телефону?</h2>
                <p>Позвоните нам +7 (343) 300-3-600 или оставьте номер для связи, и наш<br>  
                 эксперт проконсультирует Вас бесплатно</p>
                 <div class="forma">
                 <form id="assessmentForm" action="submit_request.php" method="post">
                 <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="+7 (___) ___-__-__" required minlength="10">
                    <input type="submit" value="Отправить заявку">
                </form>
                <div id="successMessage" style="display:none;">
                    <p>Заявка отправлена</p>
        </div>
                 </div>
            </div>
            </div>
        </section>
            <script>
                // Функция для форматирования номера телефона
                function formatPhoneNumber(value) {
    // Очищаем значение от всего, кроме цифр
    const phoneNumber = value.replace(/[^\d]/g, '');

    

     // Разделяем номер на части
     const phoneNumberParts = [
        phoneNumber.slice(0, 3),
        phoneNumber.slice(3, 6),
        phoneNumber.slice(6, 8),
        phoneNumber.slice(8, 10),
    ];

    // Объединяем части в одну строку, добавляя необходимые разделители
    let formattedNumber = '';
    if (phoneNumberParts[0]) formattedNumber += '(' + phoneNumberParts[0];
    if (phoneNumberParts[0].length === 3) formattedNumber += ') ';
    if (phoneNumberParts[1]) formattedNumber += phoneNumberParts[1];
    if (phoneNumberParts[1].length === 3) formattedNumber += '-';
    if (phoneNumberParts[2]) formattedNumber += phoneNumberParts[2];
    if (phoneNumberParts[2].length === 2) formattedNumber += '-';
    if (phoneNumberParts[3]) formattedNumber += phoneNumberParts[3];

    // Добавляем префикс '+7 ' только если номер начат
    return formattedNumber ? '+7 ' + formattedNumber : '';
}

// Слушаем событие ввода в поле
document.getElementById('phoneNumber').addEventListener('input', function(event) {
    // Получаем текущее значение поля, убираем '+7 ' при обработке
    const value = event.target.value.replace(/^\+7\s*/, '');
    event.target.value = formatPhoneNumber(value);
});
            document.getElementById('assessmentForm').onsubmit = function(e) {
                e.preventDefault();
                var form = this;
                var data = new FormData(form);

                fetch(form.action, {
                    method: form.method,
                    body: data
                })
                .then(response => response.text())
                .then(text => {
                    document.getElementById('assessmentForm').style.display = 'none';
                    document.getElementById('successMessage').style.display = 'block';
                })
                .catch(error => console.error('Ошибка:', error));
            };
            </script>

        <section class="kartochki">
            <div class="filter">
            <form action="index.php" method="get">
                    <label for="category">Категория:</label>
                    <select name="category" id="category">
                        <option value="all">Все</option>
                        <option value="Новостройка">Новостройки</option>
                        <option value="Вторичка">Вторичка</option>
                    </select>

                    <label for="minPrice">Стоимость, от:</label>
                    <input type="number" id="minPrice" name="minPrice" placeholder="От">

                    <label for="maxPrice">до:</label>
                    <input type="number" id="maxPrice" name="maxPrice" placeholder="До">
                    <div>
                    <label for="minArea">Площадь, от:</label>
                    <input type="number" id="minArea" name="minArea" placeholder="От">

                    <label for="maxArea">до:</label>
                    <input type="number" id="maxArea" name="maxArea" placeholder="До">

                    <label for="name">Название:</label>
                    <input type="text" id="name" name="name" placeholder="Введите название">

                    <input type="submit" value="Применить фильтры">
                    </div>
                </form>
            </div>
            <div class="tovar">
                <!-- Место для вывода карточек товара -->
                <?php


                    // Получение параметров фильтрации из запроса
            // Получение параметров фильтрации из запроса
            $categoryName = $_GET['category'] ?? null;
            $minPrice = $_GET['minPrice'] ?? null;
            $maxPrice = $_GET['maxPrice'] ?? null;
            $minArea = $_GET['minArea'] ?? null;
            $maxArea = $_GET['maxArea'] ?? null;
            $name = $_GET['name'] ?? null;

            // Формирование базового SQL запроса
            $query = "SELECT p.*, c.Name as CategoryName FROM Properties p INNER JOIN Categories c ON p.CategoryID = c.CategoryID";
            $conditions = [];
            $parameters = [];

            // Добавление условий в запрос, если они были предоставлены
            if ($categoryName && $categoryName != 'all') {
                $conditions[] = "c.Name = :categoryName";
                $parameters[':categoryName'] = $categoryName;
            }
            if ($minPrice) {
                $conditions[] = "p.Price >= :minPrice";
                $parameters[':minPrice'] = $minPrice;
            }
            if ($maxPrice) {
                $conditions[] = "p.Price <= :maxPrice";
                $parameters[':maxPrice'] = $maxPrice;
            }
            if ($minArea) {
                $conditions[] = "p.Area >= :minArea";
                $parameters[':minArea'] = $minArea;
            }
            if ($maxArea) {
                $conditions[] = "p.Area <= :maxArea";
                $parameters[':maxArea'] = $maxArea;
            }
            if ($name) {
                $conditions[] = "p.Name LIKE :name";
                $parameters[':name'] = "%$name%";
            }

            if (!empty($conditions)) {
                $query .= " WHERE " . implode(' AND ', $conditions);
            }

            $stmt = $pdo->prepare($query);
            foreach ($parameters as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            $stmt->execute();

                    // Получение и вывод результатов
                    $properties = $stmt->fetchAll();
                    foreach ($properties as $property) {
                        echo "<div class='properties-container'>";
                        echo "<a href='property_view.php?propertyID=" . $property['PropertyID'] . "' class='property-card-link'>";
                        echo "<div class='property-card'>";
                        echo "<img src='{$property['ImageURL']}' alt='Фото недвижимости'>";
                        echo "<div class='property-card-content'>";
                        echo "<h3>{$property['Name']}</h3>";
                        echo "<p>{$property['Description']}</p>";
                        echo "<p class='property-price'>Цена: {$property['Price']}₽</p>";
                        echo "<p class='property-area'>Площадь: {$property['Area']} м²</p>";
                        echo "<p id='categ' class='property-category'>{$property['CategoryName']}</p>";
                        echo "</div>";
                        echo "</div>";
                        echo "</a>";
                        echo "</div>";
                    }
                    ?>
            </div>
        </section>

        <section class="infosec">
            <div class="info">
            <div class="text">
			
			

            <h1 class="h4">Агентство недвижимости в Сысерти «Новосёл»</h1>
                <p>Агентство недвижимости в Сысерти и Свердловской области «Новосёл» — лидер рынка с большой эксклюзивной базой объектов. К нам обращаются для покупки, продажи, аренды объектов - жилых, коммерческих, загородных, курортных и даже гаражей. В базе представлены только юридически чистые объекты, поэтому найти участок, жилье, помещение, гараж - просто и понятно. Нужна консультация? Приходите в офис, звоните по телефону <a href="tel:+73433720808">+7 (343) 372-08-08</a>.</p>
                <h2>Услуги, которые мы предлагаем</h2>
                <p>Команда агентства недвижимости «Новосёл» предлагает комплексное решение любых вопросов недвижимости - от знакомства с клиентом и выявления потребностей до проведения сделки.</p>
                <!-- <p>С нами можно:</p>
                <ul>
                    <li>Продать. Оцениваем, размещаем объявления на десятках сайтов и сообщаем о перспективах продажи объекта. Так мы ускоряем сделку и поможем быстрее найти потенциального покупателя.</li>
                    <li>Купить. Взаимодействуем с застройщиками и собственниками, поэтому предлагаем честные условия покупки, цены, подбираем удобные планировки.</li>
                    <li>Сдать. Помогаем установить цену, найти клиентов и заключить договоры.</li>
                    <li>Обменять. Беремся за дома и квартиры с ипотекой.</li>
                    <li>Подобрать новостройки. Помогаем сделать выбор, так как знаем всю информацию о каждой новостройке и учитываем мельчайшие просьбы клиента.</li>
                    <li>Выбрать коммерческую недвижимость. Подбираем объект для покупки или аренды, который принесет максимальную выгоду бизнесу.</li>
                    <li>Найти курортную недвижимость на юге России и за рубежом для проживания или инвестиций.</li>
                    <li>Приобрести загородную недвижимость. Подберем земельный участок, дом, сад, коттедж. Поможем с выбором подрядчика для строительства.</li>
                    <li>Получить юридическое сопровождение. Минимизируем риски, так как проверяем подлинность документов, наличие обременения, задолженности, претензий и т. д. Гарантируем чистоту сделки.</li>
                </ul> -->
                <p>Заходите на официальный сайт агентства недвижимости «Новосёл» и выбирайте из множества предложений. Покажем объекты в удобное для вас время.</p>
                <p>Наши специалисты помогут оформить ипотеку, рассчитают все риски и выгоды, предложат несколько вариантов квартир и банков-кредиторов.</p>
                <h2>5 причин, почему стоит обратиться в АН «Новосёл»</h2>
                <p>Работая 23 года на рынке недвижимости, мы помогаем найти покупателям «их» квартиры и дома, показываем только проверенные объекты и застройщиков. Клиенты выбирают нашу риелторскую компанию, потому что:</p>
            
            </div>
            </div>
        </section>
        <section class="Agents">
            <div class="block-agents">
                <div class="bl-agent">
                    <img src="img/1.png">
                    <div class="ag-inf">
                        <h3>Мария Ширяева</h3>
                        <p>Директор</p>
                    </div>
                </div>
                <div class="bl-agent">
                    <img src="img/2.png">
                    <div class="ag-inf">
                        <h3>Фазлыева Гуля</h3>
                        <p>Зам. директора</p>
                    </div>
                </div>
                <div class="bl-agent">
                    <img src="img/3.png">
                    <div class="ag-inf">
                        <h3>Партина Екатерина</h3>
                        <p>Спец. по недвижимости</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="Reviews">
        <?php

    // Запрос на выборку отзывов
    $sql = "SELECT * FROM Reviews ORDER BY ReviewID DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $reviews = $stmt->fetchAll();
?>

<section class="reviews-section">
    <!-- Вывод отзывов -->
    <?php foreach ($reviews as $review): ?>
        <div class="review-card">
            <div class="review-author"><?= htmlspecialchars($review['FullName']) ?></div>
            <div class="review-rating">
                <?php for ($i = 0; $i < $review['Rating']; $i++): ?>
                    <span class="fas fa-star"></span>
                <?php endfor; ?>
            </div>
            <div class="review-text"><?= htmlspecialchars($review['Text']) ?></div>
        </div>
    <?php endforeach; ?>

    <!-- Форма для оставления отзыва -->
    <div class="review-form">
        <h2>Оставьте ваш отзыв</h2>
        <form action="submit_review.php" method="post">
            <input type="text" name="fullName" placeholder="Ваше ФИО" required>
            <textarea name="text" placeholder="Текст отзыва" required></textarea>
            <select name="rating" required>
                <option value="1">1 звезда</option>
                <option value="2">2 звезды</option>
                <option value="3">3 звезды</option>
                <option value="4">4 звезды</option>
                <option value="5" selected>5 звезд</option>
            </select>
            <button type="submit">Отправить отзыв</button>
        </form>
    </div>
</section>

        </section>

        <section class="map">
        <div style="border:none; border-radius: 8px;position:relative;overflow:hidden; margin-top: 60px;">
        <a href="https://yandex.ru/maps/20595/sysert/?utm_medium=mapframe&utm_source=maps"
         style="border:none;color:#eee;font-size:12px;position:absolute;top:0px;">Сысерть</a>
         <a href="https://yandex.ru/maps/20595/sysert/house/traktovaya_ulitsa_9/YkkYfgVnTUAFQFtsfXlxc35iYg==/?ll=60.827452%2C56.502217&utm_medium=mapframe&utm_source=maps&z=17"
          style="border:none;color:#eee;font-size:12px;position:absolute;top:14px;">Трактовая улица, 9 на карте Сысерти — Яндекс Карты</a
          ><iframe src="https://yandex.ru/map-widget/v1/?ll=60.827452%2C56.502217&mode=whatshere&whatshere%5Bpoint%5D=60.827452%2C56.502216&whatshere%5Bzoom%5D=17&z=17" 
            width="100%" height="400" frameborder="1" allowfullscreen="true" style="border:none;position:relative;"></iframe></div>
        </section>
    </main>

    <footer style="margin-top: 60px;">
        <div class="fotcont">
        <p>Действительный член УПН, Сертификат POC RU РГР ОС 66 0673<br>
            © Группа компаний «Новосёл», 1999—2023.</p>
        <p>Политика по обработке персональных данных</p>
        </div>
    </footer>
</body>
</html>