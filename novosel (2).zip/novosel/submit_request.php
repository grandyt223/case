<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "novosel";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Получение номера телефона из формы
$phoneNumber = $_POST['phoneNumber'];

// Подготовка и выполнение запроса к базе данных
$stmt = $conn->prepare("INSERT INTO AssessmentRequests (PhoneNumber) VALUES (?)");
$stmt->bind_param("s", $phoneNumber);
$stmt->execute();

echo "Заявка успешно отправлена";

$stmt->close();
$conn->close();
?>
