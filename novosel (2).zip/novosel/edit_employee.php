<?php
// Подключение к базе данных и функции
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "novosel";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

function fetchEmployeeById($conn, $employeeId) {
    $stmt = $conn->prepare("SELECT * FROM Employees WHERE EmployeeID = ?");
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function updateEmployee($conn, $employeeId, $fullName, $phoneNumber, $email, $login, $role) {
    $stmt = $conn->prepare("UPDATE Employees SET FullName = ?, PhoneNumber = ?, Email = ?, Login = ?, Role = ? WHERE EmployeeID = ?");
    $stmt->bind_param("sssssi", $fullName, $phoneNumber, $email, $login, $role, $employeeId);
    $stmt->execute();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editEmployee'])) {
    $employeeId = $_POST['employeeId'];
    $fullName = $_POST['fullName'];
    $phoneNumber = $_POST['phoneNumber'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    $role = $_POST['role'];

    updateEmployee($connection, $employeeId, $fullName, $phoneNumber, $email, $login, $role);

    header('Location: admin_panel.php?section=staff'); // Перезагружаем страницу, чтобы избежать повторной отправки формы
    exit();
}

if (isset($_GET['employeeId'])) {
    $employeeId = $_GET['employeeId'];
    $employee = fetchEmployeeById($connection, $employeeId);
    if (!$employee) {
        die("Сотрудник не найден");
    }
} else {
    die("Идентификатор сотрудника не указан");
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/admin.css">
    <title>Редактирование сотрудника</title>
</head>
<body>
<div class="container">
    <h1>Редактирование сотрудника</h1>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="employeeId" value="<?php echo $employee['EmployeeID']; ?>">
        <label for="fullName">ФИО:</label>
        <input type="text" id="fullName" name="fullName" value="<?php echo $employee['FullName']; ?>" required>
        <label for="phoneNumber">Телефон:</label>
        <input type="text" id="phoneNumber" name="phoneNumber" value="<?php echo $employee['PhoneNumber']; ?>">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $employee['Email']; ?>" required>
        <label for="login">Логин:</label>
        <input type="text" id="login" name="login" value="<?php echo $employee['Login']; ?>" required>
        <label for="role">Роль:</label>
        <select id="role" name="role">
            <option value="Администратор" <?php if ($employee['Role'] === 'Администратор') echo 'selected'; ?>>Администратор</option>
            <option value="Менеджер" <?php if ($employee['Role'] === 'Менеджер') echo 'selected'; ?>>Менеджер</option>
        </select>
        <input type="submit" name="editEmployee" value="Сохранить изменения">
    </form>
</div>
</body>
</html>
