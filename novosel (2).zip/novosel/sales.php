<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <title>Новосёл | Агентство недвижимости I Сысерть</title>
</head>
<body>
<?php
    // Инициализация подключения к базе данных
    $host = '127.0.0.1';
    $db = 'novosel';
    $user = 'root'; // Ваше имя пользователя
    $pass = 'root'; // Ваш пароль
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
    ?>
    <header>
        <div class="navigation">
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="menu">
                <ul class="topmenu">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="sales.php">В продаже</a></li>
                    <li><a href="about.php">О нас</a></li>
                </ul>
            </div>
            <div class="cont">
                <a href="tel:+73433720808">+7 (343) 372-08-08</a>
            </div>
        </div>
    </header>

    <main>
        
            <script>
                // Функция для форматирования номера телефона
                function formatPhoneNumber(value) {
    // Очищаем значение от всего, кроме цифр
    const phoneNumber = value.replace(/[^\d]/g, '');

    

     // Разделяем номер на части
     const phoneNumberParts = [
        phoneNumber.slice(0, 3),
        phoneNumber.slice(3, 6),
        phoneNumber.slice(6, 8),
        phoneNumber.slice(8, 10),
    ];

    // Объединяем части в одну строку, добавляя необходимые разделители
    let formattedNumber = '';
    if (phoneNumberParts[0]) formattedNumber += '(' + phoneNumberParts[0];
    if (phoneNumberParts[0].length === 3) formattedNumber += ') ';
    if (phoneNumberParts[1]) formattedNumber += phoneNumberParts[1];
    if (phoneNumberParts[1].length === 3) formattedNumber += '-';
    if (phoneNumberParts[2]) formattedNumber += phoneNumberParts[2];
    if (phoneNumberParts[2].length === 2) formattedNumber += '-';
    if (phoneNumberParts[3]) formattedNumber += phoneNumberParts[3];

    // Добавляем префикс '+7 ' только если номер начат
    return formattedNumber ? '+7 ' + formattedNumber : '';
}

// Слушаем событие ввода в поле
document.getElementById('phoneNumber').addEventListener('input', function(event) {
    // Получаем текущее значение поля, убираем '+7 ' при обработке
    const value = event.target.value.replace(/^\+7\s*/, '');
    event.target.value = formatPhoneNumber(value);
});
            document.getElementById('assessmentForm').onsubmit = function(e) {
                e.preventDefault();
                var form = this;
                var data = new FormData(form);

                fetch(form.action, {
                    method: form.method,
                    body: data
                })
                .then(response => response.text())
                .then(text => {
                    document.getElementById('assessmentForm').style.display = 'none';
                    document.getElementById('successMessage').style.display = 'block';
                })
                .catch(error => console.error('Ошибка:', error));
            };
            </script>

        <section class="kartochki">
            <div class="filter">
            <form action="index.php" method="get">
                    <label for="category">Категория:</label>
                    <select name="category" id="category">
                        <option value="all">Все</option>
                        <option value="Новостройка">Новостройки</option>
                        <option value="Вторичка">Вторичка</option>
                    </select>

                    <label for="minPrice">Стоимость, от:</label>
                    <input type="number" id="minPrice" name="minPrice" placeholder="От">

                    <label for="maxPrice">до:</label>
                    <input type="number" id="maxPrice" name="maxPrice" placeholder="До">
                    <div>
                    <label for="minArea">Площадь, от:</label>
                    <input type="number" id="minArea" name="minArea" placeholder="От">

                    <label for="maxArea">до:</label>
                    <input type="number" id="maxArea" name="maxArea" placeholder="До">

                    <label for="name">Название:</label>
                    <input type="text" id="name" name="name" placeholder="Введите название">

                    <input type="submit" value="Применить фильтры">
                    </div>
                </form>
            </div>
            <div class="tovar">
                <!-- Место для вывода карточек товара -->
                <?php


                    // Получение параметров фильтрации из запроса
            // Получение параметров фильтрации из запроса
            $categoryName = $_GET['category'] ?? null;
            $minPrice = $_GET['minPrice'] ?? null;
            $maxPrice = $_GET['maxPrice'] ?? null;
            $minArea = $_GET['minArea'] ?? null;
            $maxArea = $_GET['maxArea'] ?? null;
            $name = $_GET['name'] ?? null;

            // Формирование базового SQL запроса
            $query = "SELECT p.*, c.Name as CategoryName FROM Properties p INNER JOIN Categories c ON p.CategoryID = c.CategoryID";
            $conditions = [];
            $parameters = [];

            // Добавление условий в запрос, если они были предоставлены
            if ($categoryName && $categoryName != 'all') {
                $conditions[] = "c.Name = :categoryName";
                $parameters[':categoryName'] = $categoryName;
            }
            if ($minPrice) {
                $conditions[] = "p.Price >= :minPrice";
                $parameters[':minPrice'] = $minPrice;
            }
            if ($maxPrice) {
                $conditions[] = "p.Price <= :maxPrice";
                $parameters[':maxPrice'] = $maxPrice;
            }
            if ($minArea) {
                $conditions[] = "p.Area >= :minArea";
                $parameters[':minArea'] = $minArea;
            }
            if ($maxArea) {
                $conditions[] = "p.Area <= :maxArea";
                $parameters[':maxArea'] = $maxArea;
            }
            if ($name) {
                $conditions[] = "p.Name LIKE :name";
                $parameters[':name'] = "%$name%";
            }

            if (!empty($conditions)) {
                $query .= " WHERE " . implode(' AND ', $conditions);
            }

            $stmt = $pdo->prepare($query);
            foreach ($parameters as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            $stmt->execute();

                    // Получение и вывод результатов
                    $properties = $stmt->fetchAll();
                    foreach ($properties as $property) {
                        echo "<div class='properties-container'>";
                        echo "<div class='property-card'>";
                        echo "<img src='{$property['ImageURL']}' alt='Фото недвижимости'>";
                        echo "<div class='property-card-content'>";
                        echo "<h3>{$property['Name']}</h3>";
                        echo "<p>{$property['Description']}</p>";
                        echo "<p class='property-price'>Цена: {$property['Price']}₽</p>";
                        echo "<p class='property-area'>Площадь: {$property['Area']} м²</p>";
                        echo "<p id='cate' class='property-category'>{$property['CategoryName']}</p>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                    }
                    ?>
            </div>
        </section>




    </main>

    <footer style="margin-top: 60px;">
        <div class="fotcont">
        <p>Действительный член УПН, Сертификат POC RU РГР ОС 66 0673<br>
            © Группа компаний «Новосёл», 1999—2023.</p>
        <p>Политика по обработке персональных данных</p>
        </div>
    </footer>
</body>
</html>