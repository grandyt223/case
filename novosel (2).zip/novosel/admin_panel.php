<?php
session_start();

// Установите ваше реальное подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "novosel";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Проверяем, авторизован ли пользователь как администратор
if ($_SESSION['role'] !== 'Администратор') {
    // Если нет, перенаправляем на страницу входа
    header('Location: login.php');
    exit();
}

// Здесь должны быть функции fetchRequests и markAsRead, если они используются
// Проверяем, есть ли запрос на отметку заявки как прочитанной
if (isset($_GET['markRead'])) {
    markAsRead($connection, $_GET['markRead']);
    header('Location: admin_panel.php?section=requests'); // Перезагружаем страницу, чтобы избежать повторной отправки формы
    exit();
}

// Получаем список заявок
$requests = fetchRequests($connection);

// Функция для получения заявок из базы данных
function fetchRequests($connection) {
    $sql = "SELECT RequestID, PhoneNumber, Status FROM AssessmentRequests";
    $result = $connection->query($sql);
    $requests = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $requests[] = $row;
        }
    }
    return $requests;
}

// Функция для обновления статуса заявки
function markAsRead($connection, $requestId) {
    $sql = "UPDATE AssessmentRequests SET Status='Прочитано' WHERE RequestID=?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $stmt->close();
}
// Получаем список сотрудников
$employees = fetchEmployees($connection);

// Функция для получения списка сотрудников
function fetchEmployees($conn) {
    $sql = "SELECT EmployeeID, FullName, PhoneNumber, Email, Login, Role FROM Employees";
    $result = $conn->query($sql);
    $employees = [];
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    return $employees;
}

// Функция для добавления нового сотрудника
function addEmployee($conn, $fullName, $phoneNumber, $email, $login, $password, $role) {
    $stmt = $conn->prepare("INSERT INTO Employees (FullName, PhoneNumber, Email, Login, Password, Role) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $fullName, $phoneNumber, $email, $login, $password, $role);
    $stmt->execute();
    if ($stmt->error) {
        return $stmt->error;
    }
    $stmt->close();
    return '';
}

$errorMessage = '';
// Функция для удаления сотрудника
function deleteEmployee($conn, $employeeId) {
    $stmt = $conn->prepare("DELETE FROM Employees WHERE EmployeeID = ?");
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $stmt->close();
}

// Обработка запроса на удаление сотрудника
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['deleteEmployee'])) {
    $employeeId = $_POST['employeeId'];
    deleteEmployee($connection, $employeeId);
    header('Location: admin_panel.php?section=staff'); // Перезагружаем страницу, чтобы избежать повторной отправки формы
    exit();
}

// Обработка отправки формы добавления сотрудника
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addEmployee'])) {
    $fullName = $_POST['fullName'];
    $phoneNumber = $_POST['phoneNumber'];
    $email = $_POST['email'];
    $login = $_POST['login'];
    $password = $_POST['password']; // В реальном приложении здесь должно быть хеширование пароля
    $role = $_POST['role'];
    
    // Попытка добавления сотрудника
    $errorMessage = addEmployee($connection, $fullName, $phoneNumber, $email, $login, $password, $role);
}
// Проверяем, есть ли запрос на удаление категории
if (isset($_GET['deleteCategory'])) {
    $deleteCategoryId = $_GET['deleteCategory'];
    deleteCategory($connection, $deleteCategoryId);
    // После удаления перенаправляем на страницу управления категориями
    header('Location: admin_panel.php?section=categories');
    exit();
}

// Проверяем, есть ли запрос на редактирование категории
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editCategory'])) {
    $editCategoryId = $_POST['categoryId'];
    $newName = $_POST['newName'];
    editCategory($connection, $editCategoryId, $newName);
    // После редактирования перенаправляем на страницу управления категориями
    header('Location: admin_panel.php?section=categories');
    exit();
}

// Проверяем, есть ли запрос на добавление новой категории
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addCategory'])) {
    $newCategoryName = $_POST['newCategoryName'];
    addCategory($connection, $newCategoryName);
    // После добавления перенаправляем на страницу управления категориями
    header('Location: admin_panel.php?section=categories');
    exit();
}

// Получаем список категорий
$categories = fetchCategories($connection);

// Функция для получения категорий из базы данных
function fetchCategories($connection) {
    $sql = "SELECT CategoryID, Name FROM Categories";
    $result = $connection->query($sql);
    $categories = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    return $categories;
}

// Функция для добавления новой категории
function addCategory($connection, $name) {
    $stmt = $connection->prepare("INSERT INTO Categories (Name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
}

// Функция для удаления категории
function deleteCategory($connection, $categoryId) {
    $stmt = $connection->prepare("DELETE FROM Categories WHERE CategoryID = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $stmt->close();
}

// Функция для редактирования категории
function editCategory($connection, $categoryId, $newName) {
    $stmt = $connection->prepare("UPDATE Categories SET Name = ? WHERE CategoryID = ?");
    $stmt->bind_param("si", $newName, $categoryId);
    $stmt->execute();
    $stmt->close();
}

$connection->close();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/admin.css">
    <title>Административная панель</title>
</head>
<body>
    <div class="navbar">
        <a href="products.php">Недвижимость</a>
        <a href="admin_panel.php?section=staff">Персонал</a>
        <a href="admin_panel.php?section=requests">Входящие заявки</a>
        <a href="admin_panel.php?section=categories">Управление категориями</a>
    </div>
    <div class="container">
        <?php if (isset($_GET['section'])): ?>
            <?php switch ($_GET['section']):
                case 'properties':
                    // Код для управления недвижимостью
                    echo '<h1>Управление недвижимостью</h1>';
                    break;
                case 'staff': ?>
                    <h1>Управление персоналом</h1>
                    <!-- Сообщение об ошибке -->
                    <?php if ($errorMessage): ?>
                        <p style="color: red;"><?php echo $errorMessage; ?></p>
                    <?php endif; ?>
                    <!-- Таблица сотрудников -->
                    <table>
                        <tr>
                            <th>ID</th>
                            <th>ФИО</th>
                            <th>Телефон</th>
                            <th>Email</th>
                            <th>Логин</th>
                            <th>Роль</th>
                            <th>Редактирование</th>
                            <th>Удаление</th>
                        </tr>
                        <?php foreach ($employees as $employee): ?>
                            <tr>
                                <td><?php echo $employee['EmployeeID']; ?></td>
                                <td><?php echo $employee['FullName']; ?></td>
                                <td><?php echo $employee['PhoneNumber']; ?></td>
                                <td><?php echo $employee['Email']; ?></td>
                                <td><?php echo $employee['Login']; ?></td>
                                <td><?php echo $employee['Role']; ?></td>
                                <td>
                                <form method="post" action="edit_employee.php?employeeId=<?php echo $employee['EmployeeID']; ?>">
                                    <input type="submit" value="Редактировать">
                                </form>
                                </td>
                                <td>
                                    <form method="post" action="<?php echo $_SERVER['PHP_SELF'] . '?section=staff'; ?>">
                                        <input type="hidden" name="employeeId" value="<?php echo $employee['EmployeeID']; ?>">
                                        <input type="submit" name="deleteEmployee" value="Удалить">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                    <form method="post" action="">
                        <input name="fullName" type="text" placeholder="ФИО" required>
                        <input name="phoneNumber" type="text" placeholder="Телефон">
                        <input name="email" type="email" placeholder="Email" required>
                        <input name="login" type="text" placeholder="Логин" required>
                        <input name="password" type="password" placeholder="Пароль" required>
                        <select name="role">
                            <option value="Администратор">Администратор</option>
                            <option value="Менеджер">Менеджер</option>
                        </select>
                        <input type="submit" name="addEmployee" value="Добавить сотрудника">
                    </form>
                    <?php break;
                case 'requests': ?>
                    <h1>Входящие заявки</h1>
                    <table class="requests-table">
                        <tr>
                            <th>ID</th>
                            <th>Номер телефона</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                        <?php foreach ($requests as $request): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request['RequestID']); ?></td>
                                <td><?php echo htmlspecialchars($request['PhoneNumber']); ?></td>
                                <td><?php echo htmlspecialchars($request['Status']) ?: 'Не прочитано'; ?></td>
                                <td>
                                    <?php if ($request['Status'] !== 'Прочитано'): ?>
                                        <a href="admin_panel.php?section=requests&markRead=<?php echo $request['RequestID']; ?>" class="mark-read">Отметить как прочитанное</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                    <?php break;
                    case 'categories': ?>
                        <h1>Управление категориями</h1>
                        <h2>Список категорий</h2>
                        <ul>
                            <?php foreach ($categories as $category): ?>
                                <li>
                                    <?php echo $category['Name']; ?>
                                    <a href="admin_panel.php?section=categories&deleteCategory=<?php echo $category['CategoryID']; ?>">Удалить</a>
                                    <form method="post" action="admin_panel.php?section=categories">
                                        <input type="hidden" name="categoryId" value="<?php echo $category['CategoryID']; ?>">
                                        <input type="text" name="newName" placeholder="Новое имя">
                                        <input type="submit" name="editCategory" value="Редактировать">
                                    </form>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <h2>Добавить новую категорию</h2>
                        <form method="post" action="admin_panel.php?section=categories">
                            <input name="newCategoryName" type="text" placeholder="Название категории" required>
                            <input type="submit" name="addCategory" value="Добавить категорию">
                        </form>
                        <?php break;
                default:
                    echo '<h1>Добро пожаловать в административную панель</h1>';
                    break;
            endswitch; ?>
        <?php endif; ?>
    </div>
</body>
</html>