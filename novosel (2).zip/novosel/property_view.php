<?php
// Подключение к базе данных
$host = '127.0.0.1';
$db = 'novosel';
$user = 'root';
$pass = 'root';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Получение ID товара из GET-запроса
$propertyID = $_GET['propertyID'] ?? null;

if (!$propertyID) {
    echo "Товар не найден";
    exit;
}

// Запрос информации о товаре
$stmt = $pdo->prepare("SELECT * FROM Properties WHERE PropertyID = ?");
$stmt->execute([$propertyID]);
$property = $stmt->fetch();

// Запрос изображений товара
$stmt = $pdo->prepare("SELECT ImageURL FROM PropertyImages WHERE PropertyID = ?");
$stmt->execute([$propertyID]);
$additionalImages = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/propview.css">
    <title><?= htmlspecialchars($property['Name']) ?></title>
</head>
<body>
<header>
        <div class="navigation">
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="menu">
                <ul class="topmenu">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="sales.php">В продаже</a></li>
                    <li><a href="about.php">О нас</a></li>
                </ul>
            </div>
            <div class="cont">
                <a href="tel:+73433720808">+7 (343) 372-08-08</a>
            </div>
        </div>
    </header>
    <div class="property-view-container">
        <div class="property-images">
            <img id="mainImage" src="<?= htmlspecialchars($property['ImageURL']) ?>" class="property-image" onclick="openModal(this.src)">
            <div class="image-thumbnails">
                <?php foreach ($additionalImages as $image): ?>
                    <img src="<?= htmlspecialchars($image['ImageURL']) ?>" class="image-thumbnail" onclick="changeImage(this.src)">
                <?php endforeach; ?>
            </div>
        </div>
        <div class="property-details">
            <h1><?= htmlspecialchars($property['Name']) ?></h1>
            <p><?= nl2br(htmlspecialchars($property['Description'])) ?></p>
            <p><strong>Цена:</strong> <?= htmlspecialchars($property['Price']) ?>₽</p>
            <p><strong>Площадь:</strong> <?= htmlspecialchars($property['Area']) ?> м²</p>
            <!-- Дополнительные детали -->
        </div>
    </div>

    <!-- Модальное окно для отображения полного изображения
    <div id="imageModal" class="modal" onclick="closeModal()">
        <span onclick="closeModal()" style="color: white; cursor: pointer; position: absolute; top: 10px; right: 20px; font-size: 30px;">&times;</span>
        <div class="modal-content">
            <img id="fullImage">
        </div>
    </div>

    <script>
function changeImage(src) {
            document.getElementById('mainImage').src = src;
        }

        function openModal(src) {
            document.getElementById('fullImage').src = src;
            document.getElementById('imageModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('imageModal').style.display = 'none';
        }

        // Закрытие модального окна при клике вне изображения
        window.onclick = function(event) {
            if (event.target == document.getElementById('imageModal')) {
                closeModal();
            }
        }
    </script> -->
    <script>
function changeImage(src) {
            document.getElementById('mainImage').src = src;
        }
        </script>
</body>
</html>
