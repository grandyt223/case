-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 09 2024 г., 17:39
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `novosel`
--

-- --------------------------------------------------------

--
-- Структура таблицы `AssessmentRequests`
--

CREATE TABLE `AssessmentRequests` (
  `RequestID` int NOT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `PropertyID` int DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `AssessmentRequests`
--

INSERT INTO `AssessmentRequests` (`RequestID`, `PhoneNumber`, `PropertyID`, `Status`) VALUES
(3, '+7 (999) 888-77-66', NULL, 'Прочитано');

-- --------------------------------------------------------

--
-- Структура таблицы `Categories`
--

CREATE TABLE `Categories` (
  `CategoryID` int NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Categories`
--

INSERT INTO `Categories` (`CategoryID`, `Name`) VALUES
(1, 'Дистанционная'),
(2, 'Очная');

-- --------------------------------------------------------

--
-- Структура таблицы `Employees`
--

CREATE TABLE `Employees` (
  `EmployeeID` int NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `PhoneNumber` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Login` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Role` varchar(255) DEFAULT NULL,
  `Avatar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Employees`
--

INSERT INTO `Employees` (`EmployeeID`, `FullName`, `PhoneNumber`, `Email`, `Login`, `Password`, `Role`, `Avatar`) VALUES
(1, 'Администратор', '1000-7', 'admin@admin.com', 'admin', 'admin', 'Администратор', NULL),
(2, 'Менеджер', '993-7', 'manager@manager.com', 'manager', 'manager', 'Менеджер', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `Properties`
--

CREATE TABLE `Properties` (
  `PropertyID` int NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text,
  `Price` decimal(10,2) DEFAULT NULL,
  `Area` decimal(10,2) DEFAULT NULL,
  `ArticleNumber` varchar(255) DEFAULT NULL,
  `Floor` int DEFAULT NULL,
  `CategoryID` int DEFAULT NULL,
  `ImageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Properties`
--

INSERT INTO `Properties` (`PropertyID`, `Name`, `Description`, `Price`, `Area`, `ArticleNumber`, `Floor`, `CategoryID`, `ImageURL`) VALUES
(7, '768678', '213123', '123123.00', '6786.00', '678678', 678, 1, 'img/fa51a4b889de6cb70abbdffdcffd7354.webp'),
(9, 'Test', '123123', '123123.00', '123123.00', '123123', 123, 2, 'img/Arctic_Circle_oil_spill_ESA22056844.gif'),
(10, 'Test31', '123123', '123123.00', '123123.00', '123123', 123, 2, 'img/Arctic_Circle_oil_spill_ESA22056844.gif'),
(11, 'Test32', '123123', '123123.00', '123123.00', '123123', 123, 2, 'img/Arctic_Circle_oil_spill_ESA22056844.gif'),
(12, 'Test34', '123123', '123123.00', '123123.00', '123123', 123, 2, 'img/Arctic_Circle_oil_spill_ESA22056844.gif'),
(13, ' aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh ', ' aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh  aowidh aowidh aowidh aowidh aowidh aowidh aowidh aowidh ', '8123.00', '781273.00', '1723', 9, 1, 'img/653508abbc941_1620464536_5-p-kvartira-posle-remonta-s-mebelyu-6.jpg'),
(14, 'Разработчик WEB - сайтов', 'Требуется: опыт работы 1 год', '60000.00', '1.00', '12', 12, 1, 'img/5.jpg'),
(15, 'Разработчик WEB - сайтов', 'Требуется: опыт работы 1 год', '60000.00', '1.00', '12', 12, 1, 'img/5.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `PropertyImages`
--

CREATE TABLE `PropertyImages` (
  `ImageID` int NOT NULL,
  `PropertyID` int DEFAULT NULL,
  `ImageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `PropertyImages`
--

INSERT INTO `PropertyImages` (`ImageID`, `PropertyID`, `ImageURL`) VALUES
(1, 7, 'img/fa51a4b889de6cb70abbdffdcffd7354.webp'),
(2, 7, 'img/653508abbc941_1620464536_5-p-kvartira-posle-remonta-s-mebelyu-6.jpg'),
(6, 13, 'img/653508abbd18e_g26_main.jpg'),
(7, 13, 'img/653508abbd72e_efa7dc28f798b2333279152e8e348a36.jpeg'),
(8, 13, 'img/653508abbde02_129551071.jpg'),
(9, 14, 'img/5.jpg'),
(10, 15, 'img/5.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `PropertyListings`
--

CREATE TABLE `PropertyListings` (
  `ListingID` int NOT NULL,
  `PropertyID` int DEFAULT NULL,
  `TypeID` int DEFAULT NULL,
  `ListingDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `PropertyTypes`
--

CREATE TABLE `PropertyTypes` (
  `TypeID` int NOT NULL,
  `TypeName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `Reviews`
--

CREATE TABLE `Reviews` (
  `ReviewID` int NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `Text` text NOT NULL,
  `Rating` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Reviews`
--

INSERT INTO `Reviews` (`ReviewID`, `FullName`, `Text`, `Rating`) VALUES
(1, 'Наталья Александровна Безрукова', 'Тестовый отзыв, проверка формы', 5),
(2, 'Наталья Александровна Безрукова', 'Тестовый отзыв, проверка формы', 3);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `AssessmentRequests`
--
ALTER TABLE `AssessmentRequests`
  ADD PRIMARY KEY (`RequestID`),
  ADD KEY `PropertyID` (`PropertyID`);

--
-- Индексы таблицы `Categories`
--
ALTER TABLE `Categories`
  ADD PRIMARY KEY (`CategoryID`);

--
-- Индексы таблицы `Employees`
--
ALTER TABLE `Employees`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Индексы таблицы `Properties`
--
ALTER TABLE `Properties`
  ADD PRIMARY KEY (`PropertyID`),
  ADD KEY `CategoryID` (`CategoryID`);

--
-- Индексы таблицы `PropertyImages`
--
ALTER TABLE `PropertyImages`
  ADD PRIMARY KEY (`ImageID`),
  ADD KEY `PropertyID` (`PropertyID`);

--
-- Индексы таблицы `PropertyListings`
--
ALTER TABLE `PropertyListings`
  ADD PRIMARY KEY (`ListingID`),
  ADD KEY `PropertyID` (`PropertyID`),
  ADD KEY `TypeID` (`TypeID`);

--
-- Индексы таблицы `PropertyTypes`
--
ALTER TABLE `PropertyTypes`
  ADD PRIMARY KEY (`TypeID`);

--
-- Индексы таблицы `Reviews`
--
ALTER TABLE `Reviews`
  ADD PRIMARY KEY (`ReviewID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `AssessmentRequests`
--
ALTER TABLE `AssessmentRequests`
  MODIFY `RequestID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Categories`
--
ALTER TABLE `Categories`
  MODIFY `CategoryID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `Employees`
--
ALTER TABLE `Employees`
  MODIFY `EmployeeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Properties`
--
ALTER TABLE `Properties`
  MODIFY `PropertyID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `PropertyImages`
--
ALTER TABLE `PropertyImages`
  MODIFY `ImageID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `PropertyListings`
--
ALTER TABLE `PropertyListings`
  MODIFY `ListingID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `PropertyTypes`
--
ALTER TABLE `PropertyTypes`
  MODIFY `TypeID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Reviews`
--
ALTER TABLE `Reviews`
  MODIFY `ReviewID` int NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `AssessmentRequests`
--
ALTER TABLE `AssessmentRequests`
  ADD CONSTRAINT `assessmentrequests_ibfk_1` FOREIGN KEY (`PropertyID`) REFERENCES `Properties` (`PropertyID`);

--
-- Ограничения внешнего ключа таблицы `Properties`
--
ALTER TABLE `Properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `Categories` (`CategoryID`);

--
-- Ограничения внешнего ключа таблицы `PropertyImages`
--
ALTER TABLE `PropertyImages`
  ADD CONSTRAINT `propertyimages_ibfk_1` FOREIGN KEY (`PropertyID`) REFERENCES `Properties` (`PropertyID`);

--
-- Ограничения внешнего ключа таблицы `PropertyListings`
--
ALTER TABLE `PropertyListings`
  ADD CONSTRAINT `propertylistings_ibfk_1` FOREIGN KEY (`PropertyID`) REFERENCES `Properties` (`PropertyID`),
  ADD CONSTRAINT `propertylistings_ibfk_2` FOREIGN KEY (`TypeID`) REFERENCES `PropertyTypes` (`TypeID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
