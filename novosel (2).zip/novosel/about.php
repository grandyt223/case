<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <title>Новосёл | Агентство недвижимости I Сысерть</title>
</head>
<body>
<?php
    // Инициализация подключения к базе данных
    $host = '127.0.0.1';
    $db = 'novosel';
    $user = 'root'; // Ваше имя пользователя
    $pass = 'root'; // Ваш пароль
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
    ?>
    <header>
        <div class="navigation">
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="menu">
                <ul class="topmenu">
                    <li><a href="index.php">Главная</a></li>
                    <li><a href="sales.php">В продаже</a></li>
                    <li><a href="about.php">О нас</a></li>
                </ul>
            </div>
            <div class="cont">
                <a href="tel:+73433720808">+7 (343) 372-08-08</a>
            </div>
        </div>
    </header>

    <main>
       
            <script>
                // Функция для форматирования номера телефона
                function formatPhoneNumber(value) {
    // Очищаем значение от всего, кроме цифр
    const phoneNumber = value.replace(/[^\d]/g, '');

    

     // Разделяем номер на части
     const phoneNumberParts = [
        phoneNumber.slice(0, 3),
        phoneNumber.slice(3, 6),
        phoneNumber.slice(6, 8),
        phoneNumber.slice(8, 10),
    ];

    // Объединяем части в одну строку, добавляя необходимые разделители
    let formattedNumber = '';
    if (phoneNumberParts[0]) formattedNumber += '(' + phoneNumberParts[0];
    if (phoneNumberParts[0].length === 3) formattedNumber += ') ';
    if (phoneNumberParts[1]) formattedNumber += phoneNumberParts[1];
    if (phoneNumberParts[1].length === 3) formattedNumber += '-';
    if (phoneNumberParts[2]) formattedNumber += phoneNumberParts[2];
    if (phoneNumberParts[2].length === 2) formattedNumber += '-';
    if (phoneNumberParts[3]) formattedNumber += phoneNumberParts[3];

    // Добавляем префикс '+7 ' только если номер начат
    return formattedNumber ? '+7 ' + formattedNumber : '';
}

// Слушаем событие ввода в поле
document.getElementById('phoneNumber').addEventListener('input', function(event) {
    // Получаем текущее значение поля, убираем '+7 ' при обработке
    const value = event.target.value.replace(/^\+7\s*/, '');
    event.target.value = formatPhoneNumber(value);
});
            document.getElementById('assessmentForm').onsubmit = function(e) {
                e.preventDefault();
                var form = this;
                var data = new FormData(form);

                fetch(form.action, {
                    method: form.method,
                    body: data
                })
                .then(response => response.text())
                .then(text => {
                    document.getElementById('assessmentForm').style.display = 'none';
                    document.getElementById('successMessage').style.display = 'block';
                })
                .catch(error => console.error('Ошибка:', error));
            };
            </script>

        
        </section>

        <section class="infosec">
            <div class="info">
            <div class="text">
			
			

            <h1 class="h4">Агентство недвижимости в Сысерти «Новосёл»</h1>
                <p>Агентство недвижимости в Сысерти и Свердловской области «Новосёл» — лидер рынка с большой эксклюзивной базой объектов. К нам обращаются для покупки, продажи, аренды объектов - жилых, коммерческих, загородных, курортных и даже гаражей. В базе представлены только юридически чистые объекты, поэтому найти участок, жилье, помещение, гараж - просто и понятно. Нужна консультация? Приходите в офис, звоните по телефону <a href="tel:+73433720808">+7 (343) 372-08-08</a>.</p>
                <h2>Услуги, которые мы предлагаем</h2>
                <p>Команда агентства недвижимости «Новосёл» предлагает комплексное решение любых вопросов недвижимости - от знакомства с клиентом и выявления потребностей до проведения сделки.</p>
                <!-- <p>С нами можно:</p>
                <ul>
                    <li>Продать. Оцениваем, размещаем объявления на десятках сайтов и сообщаем о перспективах продажи объекта. Так мы ускоряем сделку и поможем быстрее найти потенциального покупателя.</li>
                    <li>Купить. Взаимодействуем с застройщиками и собственниками, поэтому предлагаем честные условия покупки, цены, подбираем удобные планировки.</li>
                    <li>Сдать. Помогаем установить цену, найти клиентов и заключить договоры.</li>
                    <li>Обменять. Беремся за дома и квартиры с ипотекой.</li>
                    <li>Подобрать новостройки. Помогаем сделать выбор, так как знаем всю информацию о каждой новостройке и учитываем мельчайшие просьбы клиента.</li>
                    <li>Выбрать коммерческую недвижимость. Подбираем объект для покупки или аренды, который принесет максимальную выгоду бизнесу.</li>
                    <li>Найти курортную недвижимость на юге России и за рубежом для проживания или инвестиций.</li>
                    <li>Приобрести загородную недвижимость. Подберем земельный участок, дом, сад, коттедж. Поможем с выбором подрядчика для строительства.</li>
                    <li>Получить юридическое сопровождение. Минимизируем риски, так как проверяем подлинность документов, наличие обременения, задолженности, претензий и т. д. Гарантируем чистоту сделки.</li>
                </ul> -->
                <p>Заходите на официальный сайт агентства недвижимости «Новосёл» и выбирайте из множества предложений. Покажем объекты в удобное для вас время.</p>
                <p>Наши специалисты помогут оформить ипотеку, рассчитают все риски и выгоды, предложат несколько вариантов квартир и банков-кредиторов.</p>
                <h2>5 причин, почему стоит обратиться в АН «Новосёл»</h2>
                <p>Работая 23 года на рынке недвижимости, мы помогаем найти покупателям «их» квартиры и дома, показываем только проверенные объекты и застройщиков. Клиенты выбирают нашу риелторскую компанию, потому что:</p>
            
            </div>
            </div>
        </section>

        <section class="map">
        <div style="border:none; border-radius: 8px;position:relative;overflow:hidden; margin-top: 60px;">
        <a href="https://yandex.ru/maps/20595/sysert/?utm_medium=mapframe&utm_source=maps"
         style="border:none;color:#eee;font-size:12px;position:absolute;top:0px;">Сысерть</a>
         <a href="https://yandex.ru/maps/20595/sysert/house/traktovaya_ulitsa_9/YkkYfgVnTUAFQFtsfXlxc35iYg==/?ll=60.827452%2C56.502217&utm_medium=mapframe&utm_source=maps&z=17"
          style="border:none;color:#eee;font-size:12px;position:absolute;top:14px;">Трактовая улица, 9 на карте Сысерти — Яндекс Карты</a
          ><iframe src="https://yandex.ru/map-widget/v1/?ll=60.827452%2C56.502217&mode=whatshere&whatshere%5Bpoint%5D=60.827452%2C56.502216&whatshere%5Bzoom%5D=17&z=17" 
            width="100%" height="400" frameborder="1" allowfullscreen="true" style="border:none;position:relative;"></iframe></div>
        </section>
    </main>

    <footer style="margin-top: 60px;">
        <div class="fotcont">
        <p>Действительный член УПН, Сертификат POC RU РГР ОС 66 0673<br>
            © Группа компаний «Новосёл», 1999—2023.</p>
        <p>Политика по обработке персональных данных</p>
        </div>
    </footer>
</body>
</html>