<?php
session_start();

$host = "localhost"; // Замените на адрес вашего сервера
$username = "root"; // Замените на ваше имя пользователя БД
$password = "root"; // Замените на ваш пароль БД
$dbname = "novosel"; // Замените на имя вашей базы данных

$connection = new mysqli($host, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$loginErrorMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $connection->real_escape_string($_POST['login']);
    $password = $connection->real_escape_string($_POST['password']); // В реальных условиях здесь должно быть хеширование

    $sql = "SELECT EmployeeID, FullName, Role FROM Employees WHERE Login = '$login' AND Password = '$password'";
    $result = $connection->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['EmployeeID'];
        $_SESSION['role'] = $user['Role'];
        $_SESSION['full_name'] = $user['FullName'];

        if ($user['Role'] == 'Администратор') {
            header("Location: admin_panel.php");
            exit();
        } elseif ($user['Role'] == 'Менеджер') {
            header("Location: manager_page.php");
            exit();
        }
    } else {
        $loginErrorMessage = "Неверные логин или пароль.";
    }
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Авторизация</title>
    <link rel="stylesheet" href="css/login.css">
    <!-- Стилизация -->
</head>
<body>
    <div class="login-container">
        <?php if ($loginErrorMessage != ""): ?>
            <p><?php echo $loginErrorMessage; ?></p>
        <?php endif; ?>
        <form method="post">
            <label for="login">Логин:</label>
            <input type="text" id="login" name="login" required>
            
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
            
            <input type="submit" value="Войти">
        </form>
    </div>
</body>
</html>
