<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "novosel"; // Имя вашей базы данных

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Проверяем, существует ли столбец ImageURL в таблице Properties
$sql = "SHOW COLUMNS FROM Properties LIKE 'ImageURL'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Если столбец ImageURL не существует, создаем его
    $sql = "ALTER TABLE Properties ADD ImageURL VARCHAR(255)";
    if ($conn->query($sql) === TRUE) {
        echo "Столбец ImageURL успешно создан.";
    } else {
        echo "Ошибка при создании столбца ImageURL: " . $conn->error;
    }
}

// Проверяем, существует ли столбец ImageID в таблице PropertyImages
$sql = "SHOW COLUMNS FROM PropertyImages LIKE 'ImageID'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Если столбец ImageID не существует, создаем его
    $sql = "ALTER TABLE PropertyImages ADD ImageID INT AUTO_INCREMENT PRIMARY KEY";
    if ($conn->query($sql) === TRUE) {
        echo "Столбец ImageID успешно создан.";
    } else {
        echo "Ошибка при создании столбца ImageID: " . $conn->error;
    }
}

// Проверяем, существует ли столбец ImageURL в таблице PropertyImages
$sql = "SHOW COLUMNS FROM PropertyImages LIKE 'ImageURL'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Если столбец ImageURL не существует, создаем его
    $sql = "ALTER TABLE PropertyImages ADD ImageURL VARCHAR(255)";
    if ($conn->query($sql) === TRUE) {
        echo "Столбец ImageURL успешно создан.";
    } else {
        echo "Ошибка при создании столбца ImageURL: " . $conn->error;
    }
}

// Функция для добавления товара
function addProduct($conn, $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $mainImageURL, $additionalImages) {
    // Вставка товара в таблицу Properties
    $sql = "INSERT INTO Properties (Name, Description, Price, Area, ArticleNumber, Floor, CategoryID, ImageURL) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Ошибка подготовки запроса: " . $conn->error);
    }
    $stmt->bind_param("ssddssis", $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $mainImageURL);
    
    if ($stmt->execute()) {
        // Получаем ID последней добавленной записи
        $lastID = $conn->insert_id;
        
        // Вставка дополнительных изображений в таблицу PropertyImages
        foreach ($additionalImages as $imageURL) {
            $sql = "INSERT INTO PropertyImages (PropertyID, ImageURL) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                die("Ошибка подготовки запроса: " . $conn->error);
            }
            $stmt->bind_param("is", $lastID, $imageURL);
            $stmt->execute();
        }

        return true; // Успешно добавлено
    } else {
        return false; // Ошибка при добавлении
    }
}

// Функция для редактирования товара
function editProduct($conn, $productID, $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $newMainImage, $newAdditionalImages) {
    // Обновление информации о товаре в таблице Properties
    $sql = "UPDATE Properties SET Name=?, Description=?, Price=?, Area=?, ArticleNumber=?, Floor=?, CategoryID=? WHERE PropertyID=?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Ошибка подготовки запроса: " . $conn->error);
    }
    $stmt->bind_param("ssddssii", $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $productID);
    
    if ($stmt->execute()) {
        // Если загружено новое основное изображение, обновляем путь к изображению в таблице Properties
        if ($newMainImage) {
            $mainImageURL = "img/" . basename($newMainImage["name"]);
            if (move_uploaded_file($newMainImage["tmp_name"], $mainImageURL)) {
                $sql = "UPDATE Properties SET ImageURL=? WHERE PropertyID=?";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    die("Ошибка подготовки запроса: " . $conn->error);
                }
                $stmt->bind_param("si", $mainImageURL, $productID);
                $stmt->execute();
            } else {
                die("Ошибка при загрузке нового основного изображения.");
            }
        }

        // Удаляем все дополнительные изображения товара из таблицы PropertyImages
        $sql = "DELETE FROM PropertyImages WHERE PropertyID=?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Ошибка подготовки запроса: " . $conn->error);
        }
        $stmt->bind_param("i", $productID);
        $stmt->execute();

        // Вставляем новые дополнительные изображения в таблицу PropertyImages
        foreach ($newAdditionalImages["tmp_name"] as $key => $tmp_name) {
            $temp = $newAdditionalImages["tmp_name"][$key];
            $additionalImageURL = "img/" . basename($newAdditionalImages["name"][$key]);
            if (move_uploaded_file($temp, $additionalImageURL)) {
                $sql = "INSERT INTO PropertyImages (PropertyID, ImageURL) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    die("Ошибка подготовки запроса: " . $conn->error);
                }
                $stmt->bind_param("is", $productID, $additionalImageURL);
                $stmt->execute();
            } else {
                die("Ошибка при загрузке нового дополнительного изображения.");
            }
        }

        return true; // Успешно отредактировано
    } else {
        return false; // Ошибка при редактировании
    }
}

// Пример использования функции для добавления товара
if (isset($_POST['addProduct'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $area = $_POST['area'];
    $articleNumber = $_POST['articleNumber'];
    $floor = $_POST['floor'];
    $categoryID = $_POST['categoryID'];

    // Обработка загрузки основного изображения
    $targetDir = "img/";
    $mainImageURL = $targetDir . basename($_FILES["mainImage"]["name"]);
    if (move_uploaded_file($_FILES["mainImage"]["tmp_name"], $mainImageURL)) {
        // Обработка загрузки дополнительных изображений
        $additionalImages = array();
        foreach ($_FILES["additionalImages"]["tmp_name"] as $key => $tmp_name) {
            $temp = $_FILES["additionalImages"]["tmp_name"][$key];
            $additionalImageURL = $targetDir . basename($_FILES["additionalImages"]["name"][$key]);
            if (move_uploaded_file($temp, $additionalImageURL)) {
                $additionalImages[] = $additionalImageURL;
            } else {
                echo "Ошибка при загрузке дополнительного изображения.";
                exit();
            }
        }

        if (addProduct($conn, $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $mainImageURL, $additionalImages)) {
            echo "Товар успешно добавлен!";
        } else {
            echo "Ошибка при добавлении товара.";
        }
    } else {
        echo "Ошибка при загрузке основного изображения.";
    }
}

// Пример использования функции для редактирования товара
if (isset($_POST['editProduct'])) {
    $productID = $_POST['productID'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $area = $_POST['area'];
    $articleNumber = $_POST['articleNumber'];
    $floor = $_POST['floor'];
    $categoryID = $_POST['categoryID'];

    // Обработка загрузки нового основного изображения
    $newMainImage = $_FILES["newMainImage"];
    // Обработка загрузки новых дополнительных изображений
    $newAdditionalImages = $_FILES["newAdditionalImages"];

    if (editProduct($conn, $productID, $name, $description, $price, $area, $articleNumber, $floor, $categoryID, $newMainImage, $newAdditionalImages)) {
        echo "Товар успешно отредактирован!";
    } else {
        echo "Ошибка при редактировании товара.";
    }
}

// Получение списка категорий
$sql = "SELECT * FROM Categories";
$result = $conn->query($sql);

$categories = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}

// Получение списка товаров
$sql = "SELECT * FROM Properties";
$result = $conn->query($sql);

$products = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}
// Обработка запроса на удаление товара
if (isset($_GET['deleteProduct'])) {
    $productID = $_GET['deleteProduct'];

    // SQL запрос для удаления товара по ID
    $sql = "DELETE FROM Properties WHERE PropertyID = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Ошибка подготовки запроса: " . $conn->error);
    }
    $stmt->bind_param("i", $productID);

    if ($stmt->execute()) {
        echo "Товар успешно удален!";
        // После удаления товара, перенаправьте пользователя на ту же страницу
        header("Location: products.php");
        exit();
    } else {
        echo "Ошибка при удалении товара.";
    }
}

// Закрытие соединения с базой данных
$conn->close();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/propert.css">
    <title>Административная панель</title>
</head>
<body>
    <div class="navbar">
        <a href="products.php">Недвижимость</a>
        <a href="admin_panel.php?section=staff">Персонал</a>
        <a href="admin_panel.php?section=requests">Входящие заявки</a>
        <a href="admin_panel.php?section=categories">Управление категориями</a>
    </div>
    <div class="container">
        <h1>Управление товарами</h1>
        
        <!-- Форма для добавления нового товара -->
        <h2>Добавить новый товар</h2>
        <form method="post" action="" enctype="multipart/form-data">
            <label for="name">Название:</label>
            <input type="text" id="name" name="name" required>
            <label for="description">Описание:</label>
            <textarea id="description" name="description" required></textarea>
            <label for="price">Цена:</label>
            <input type="number" id="price" name="price" step="0.01" required>
            <label for="area">Площадь:</label>
            <input type="number" id="area" name="area" step="0.01" required>
            <label for="articleNumber">Артикул:</label>
            <input type="text" id="articleNumber" name="articleNumber" required>
            <label for="floor">Этаж:</label>
            <input type="number" id="floor" name="floor" required>
            <label for="categoryID">Категория:</label>
            <select id="categoryID" name="categoryID" required>
                <?php foreach ($categories as $category) : ?>
                    <option value="<?= $category['CategoryID'] ?>"><?= $category['Name'] ?></option>
                <?php endforeach; ?>
            </select>
            <label for="mainImage">Основное изображение:</label>
            <input type="file" id="mainImage"  name="mainImage" accept="image/*" required>
            <label for="additionalImages">Дополнительные изображения:</label>
            <input type="file" id="additionalImages" name="additionalImages[]" accept="image/*" multiple required>
            <input type="submit" name="addProduct" value="Добавить">
        </form>

        <!-- Таблица с товарами -->
        <h2>Список товаров</h2>
        <table>
            <tr>
                <th>Название</th>
                <th>Описание</th>
                <th>Цена</th>
                <th>Площадь</th>
                <th>Артикул</th>
                <th>Этаж</th>
                <th>Категория</th>
                <th>Изображение</th>
                <th>Действия</th>
            </tr>

            <?php foreach ($products as $product) : ?>
                <tr>
                    <td><?= $product['Name'] ?></td>
                    <td><?= $product['Description'] ?></td>
                    <td><?= $product['Price'] ?></td>
                    <td><?= $product['Area'] ?></td>
                    <td><?= $product['ArticleNumber'] ?></td>
                    <td><?= $product['Floor'] ?></td>
                    <td><?= $product['CategoryID'] ?></td>
                    <!-- Устанавливаем src атрибут на путь к основному изображению из базы данных -->
                    <td><img src="<?= $product['ImageURL'] ?>" alt="<?= $product['Name'] ?>"></td>
                    <td>
                        <form method="post" action="" enctype="multipart/form-data">
                            <input type="hidden" name="productID" value="<?= $product['PropertyID'] ?>">
                            <label for="name">Новое название:</label>
                            <input type="text" id="name" name="name" value="<?= $product['Name'] ?>">
                            <label for="description">Новое описание:</label>
                            <textarea id="description" name="description"><?= $product['Description'] ?></textarea>
                            <label for="price">Новая цена:</label>
                            <input type="number" id="price" name="price" step="0.01" value="<?= $product['Price'] ?>">
                            <label for="area">Новая площадь:</label>
                            <input type="number" id="area" name="area" step="0.01" value="<?= $product['Area'] ?>">
                            <label for="articleNumber">Новый артикул:</label>
                            <input type="text" id="articleNumber" name="articleNumber" value="<?= $product['ArticleNumber'] ?>">
                            <label for="floor">Новый этаж:</label>
                            <input type="number" id="floor" name="floor" value="<?= $product['Floor'] ?>">
                            <label for="categoryID">Новая категория:</label>
                            <select id="categoryID" name="categoryID">
                                <?php foreach ($categories as $category) : ?>
                                    <option value="<?= $category['CategoryID'] ?>" <?= ($category['CategoryID'] == $product['CategoryID']) ? 'selected' : '' ?>>
                                        <?= $category['Name'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <label for="newMainImage">Новое основное изображение:</label>
                            <input type="file" id="newMainImage" name="newMainImage" accept="image/*">
                            <label for="newAdditionalImages">Новые дополнительные изображения:</label>
                            <input type="file" id="newAdditionalImages" name="newAdditionalImages[]" accept="image/*" multiple>
                            <input type="submit" name="editProduct" value="Редактировать">
                        </form>
                        <a href="?deleteProduct=<?= $product['PropertyID'] ?>">Удалить</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>

